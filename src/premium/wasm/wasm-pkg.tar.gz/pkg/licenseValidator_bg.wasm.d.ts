/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const alloc: (a: number) => number;
export const dealloc: (a: number, b: number) => void;
export const validate_signature: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_start: () => void;
